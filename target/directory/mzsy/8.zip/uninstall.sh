rm /data/adb/naki/asopt.conf
rmdir /data/adb/naki
