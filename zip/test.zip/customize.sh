# if [[ "$KSU" == "true" ]]; then
    # echo "- KernelSU 用户空间当前的版本号: $KSU_VER_CODE"
    # echo "- KernelSU 内核空间当前的版本号: $KSU_KERNEL_VER_CODE"
    # echo "*********************************************"
# # ap模块安装
# elif [[ "$APATCH" == "true" ]]; then
    # echo "- APatch 当前的版本号: $APATCH_VER_CODE"
    # echo "- APatch 当前的版本名: $APATCH_VER"
    # echo "- KernelPatch 用户空间当前的版本号: $KERNELPATCH_VERSION"
    # echo "- KernelPatch 内核空间当前的版本号: $KERNEL_VERSION"
    # echo "*********************************************"
# else
    # # 面具模块安装
    # echo "- Magisk 版本: $MAGISK_VER_CODE"
# fi
if [[ "$KSU" == "true" ]]; then
    echo "- KernelSU 用户空间版本: $KSU_VER_CODE"
    echo "- KernelSU 内核空间版本: $KSU_KERNEL_VER_CODE"
    if [[ "$KSU_SUKISU" == "true" ]]; then
        if [ "$KSU_VER_CODE" -ge 13200 ]; then
            echo "- 检测到SukiSU Ultra版本高于13200，跳过susfs管理模块刷入"
        else
            echo "- 检测到SukiSU Ultra版本低于13200，建议更新版本以管理susfs或刷入susfs管理模块"
        fi
    else
        if pm list packages | grep -q "com.rifsxd.ksunext"; then
            echo "- 检测到Ksu Next"
        else
            echo "- 不会吧不会吧你不会还在用官方版ksu吧?"
        fi
    fi
    echo "*********************************************"
# ap模块安装
elif [[ "$APATCH" == "true" ]]; then
    echo "- APatch 当前的版本号: $APATCH_VER_CODE"
    echo "- APatch 当前的版本名: $APATCH_VER"
    echo "- KernelPatch 用户空间当前的版本号: $KERNELPATCH_VERSION"
    echo "- KernelPatch 内核空间当前的版本号: $KERNEL_VERSION"
    echo "*********************************************"
else
    # 面具模块安装
    echo "- Magisk 版本: $MAGISK_VER_CODE"
fi
