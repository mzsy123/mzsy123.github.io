echo ""
echo "女朋友@HideOne123"
echo "↑✈️速来骚扰✈️↑"

sh -c /data/adb/modules/HideOne/package/pa.sh
sleep 0.2
echo "包名更新成功"
sleep 0.2
head -n 5 /data/adb/tricky_store/target.txt
